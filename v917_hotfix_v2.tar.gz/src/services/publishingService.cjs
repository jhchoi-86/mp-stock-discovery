const fs = require('fs');
const path = require('path');
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
const { saveDailyTop5 } = require('./signalReportService.cjs');
const lockManager = require('../utils/lockManager.cjs'); // Assuming this exists for mutex

/**
 * [v9.1.5] Publishing Service - Multi-Channel Synchronization SSOT
 */
class PublishingService {
    constructor() {
        this.LANDING_FILE = path.join(process.cwd(), 'data', 'landing_strategy.json');
        this.WATCHLIST_FILE = path.join(process.cwd(), 'data', 'watchlist_strategy.json');
        this.LATEST_FILE = path.join(process.cwd(), 'data', 'vip_logs', 'latest.json');
    }

    /**
     * Publish Top 5 stocks to all channels atomically
     * @param {Array} top5 - The selected Top 5 stocks from dashboard
     */
    async publishToAll(inputStocks) {
        console.log('[PublishingService] Starting multi-channel sync...');
        
        // [REDTEAM] Enforce strict Top 5 limit
        const top5 = (inputStocks || []).slice(0, 5);

        try {
            const now = new Date();
            const kstOffset = 9 * 60 * 60 * 1000;
            const kstNow = new Date(now.getTime() + kstOffset);
            const todayStr = kstNow.toISOString().split('T')[0];
            const displayDate = `${kstNow.getUTCMonth() + 1}. ${kstNow.getUTCDate()}.`;

            // 1. Smart-Merge Existing Status (Red Team Recommendation)
            // Fetch existing data to preserve "Executed/Target Reached" statuses
            const existingLatest = this.readJsonSafe(this.LATEST_FILE);
            const statusMap = {};
            if (existingLatest && existingLatest.stocks) {
                existingLatest.stocks.forEach(s => {
                    if (s.code) statusMap[s.code] = s.status;
                });
            }

            const processedStocks = top5.map(s => {
                const currentStatus = statusMap[s.code] || s.status || '분석완료';
                // Only keep priority statuses
                const status = (['보유 중', '목표 도달', '손절 완료', '체결'].includes(currentStatus)) ? currentStatus : '분석완료';
                
                // [WYSIWYS] Normalize frontend fields to SSOT standard
                return {
                    code: s.code,
                    name: s.name,
                    score: s.score || s.total_score || 0,
                    category: s.category || '추세 지속형',
                    currentPrice: s.currentPrice || s.current_price || 0,
                    entryPrice1: s.entryPrice1 || s.entry_price || s.entry1 || 0,
                    entryPrice2: s.entryPrice2 || s.entry_price_2 || s.entry2 || s.result_3 || 0,
                    stopLoss: s.stopLoss || s.stop_loss || s.sl || 0,
                    targetPrice1: s.targetPrice1 || s.target_price || s.target || s.result_1 || 0,
                    yield: s.yield || s.yield_pct || s.change_rate || 0,
                    status,
                    recommended_at: displayDate
                };
            });

            // 2. DB Update (DailyTop5) - With Error Resilience
            console.log('[PublishingService] Updating DailyTop5 DB...');
            for (const s of processedStocks) {
                try {
                    await saveDailyTop5(s.code, {
                        name: s.name,
                        score: s.score || s.total_score || 0,
                        currentPrice: s.currentPrice || s.current_price || 0,
                        changeRate: s.yield || s.yield_pct || s.change_rate || 0,
                        entryPrice1: s.entryPrice1 || s.entry_price || 0,
                        entryPrice2: s.entryPrice2 || s.entry_price_2 || 0,
                        stopLoss: s.stopLoss || s.stop_loss || 0,
                        targetPrice1: s.targetPrice1 || s.target_price || s.target_price_exit || 0,
                        trendType: s.category || '추세 지속형',
                        tradeAmount: s.tradeAmount || s.trade_amount || 0,
                        foreignBuy: s.foreignBuy || s.foreign_buy || 0,
                        instBuy: s.instBuy || s.inst_buy || 0,
                        styleTag: s.styleTag || s.style_tag || '',
                        aiComment: s.aiComment || s.ai_comment || ''
                    });
                } catch (dbErr) {
                    console.error(`[PublishingService] DB Update failed for ${s.code}, but continuing with file sync:`, dbErr.message);
                }
            }

            // 3. File Updates with Mutex & Atomic Rename (Red Team Recommendation)
            await lockManager.withLock('publish_sync', async () => {
                // 3.1 landing_strategy.json
                const landingData = {
                    updatedAt: kstNow.toISOString(),
                    stocks: processedStocks.map(s => ({
                        code: s.code,
                        name: s.name,
                        score: s.score || s.total_score || 0,
                        category: s.category || '추세 지속형',
                        entryPrice: s.entryPrice1 || s.entry_price || 0,
                        targetPrice: s.targetPrice1 || s.target_price || 0,
                        stopLoss: s.stopLoss || s.stop_loss || 0,
                        currentPrice: s.currentPrice || s.current_price || 0
                    }))
                };
                this.writeJsonAtomic(this.LANDING_FILE, landingData);

                // 3.2 latest.json (VIP Logs)
                const latestData = {
                    stocks: processedStocks, // Full data for performance page
                    header: {
                        report_date: `${displayDate}.`,
                        universe: 'MP 통합 포트폴리오 (Live)'
                    }
                };
                this.writeJsonAtomic(this.LATEST_FILE, latestData);

                // 3.3 watchlist_strategy.json (Optional but good for fallback)
                this.writeJsonAtomic(this.WATCHLIST_FILE, landingData);
            });

            console.log('[PublishingService] All channels synced successfully.');
            return { success: true, timestamp: kstNow.toISOString() };

        } catch (err) {
            console.error('[PublishingService] Sync FAILED:', err);
            throw err;
        }
    }

    /**
     * Write JSON file using Atomic Rename pattern
     */
    writeJsonAtomic(filePath, data) {
        const tmpPath = `${filePath}.tmp`;
        try {
            console.log(`[PublishingService] Writing atomic file: ${filePath}`);
            fs.writeFileSync(tmpPath, JSON.stringify(data, null, 2), 'utf8');
            fs.renameSync(tmpPath, filePath);
            console.log(`[PublishingService] File write SUCCESS: ${filePath}`);
        } catch (e) {
            console.error(`[PublishingService] File Write Error (${filePath}):`, e.message);
            if (fs.existsSync(tmpPath)) fs.unlinkSync(tmpPath);
            throw new Error(`파일 저장 실패 (${path.basename(filePath)}): ${e.message}`);
        }
    }

    readJsonSafe(filePath) {
        try {
            if (fs.existsSync(filePath)) {
                return JSON.parse(fs.readFileSync(filePath, 'utf8'));
            }
        } catch (e) {
            console.warn(`[PublishingService] Read failed for ${filePath}:`, e.message);
        }
        return null;
    }
}

module.exports = new PublishingService();
