require('dotenv').config();
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
const os = require('os');
const { exec } = require('child_process');
const redisClient = require('../../platform/infra/redis/client.cjs');

/**
 * System Stats Service
 * Handles collection of daily user activity and system resource metrics.
 */
const systemStatsService = {
  /**
   * Get Today's Date String (YYYY-MM-DD)
   */
  getToday() {
    return new Date(Date.now() + (9 * 60 * 60 * 1000)).toISOString().split('T')[0];
  },

  /**
   * Record a login event
   */
  async recordLogin() {
    const today = this.getToday();
    try {
      await prisma.systemStat.upsert({
        where: { date: today },
        update: { loginCount: { increment: 1 } },
        create: { date: today, loginCount: 1 }
      });
    } catch (err) {
      console.error('[SystemStats] Record Login Error:', err);
    }
  },

  /**
   * Record a signup event
   */
  async recordSignup() {
    const today = this.getToday();
    try {
      await prisma.systemStat.upsert({
        where: { date: today },
        update: { signupCount: { increment: 1 } },
        create: { date: today, signupCount: 1 }
      });
    } catch (err) {
      console.error('[SystemStats] Record Signup Error:', err);
    }
  },

  /**
   * Record a unique visitor (Redis-based)
   */
  async recordVisitor(identifier) {
    const today = this.getToday();
    const key = `visitors:${today}`;
    try {
      const isNew = await redisClient.sadd(key, identifier);
      if (isNew) {
        await prisma.systemStat.upsert({
          where: { date: today },
          update: { visitorCount: { increment: 1 } },
          create: { date: today, visitorCount: 1 }
        });
      }
    } catch (err) {
      console.error('[SystemStats] Record Visitor Error:', err);
    }
  },

  /**
   * Update Concurrent User Count
   */
  async updateMaxConcurrent(count) {
    const today = this.getToday();
    try {
      const current = await prisma.systemStat.findUnique({ where: { date: today } });
      if (!current || count > current.maxConcurrent) {
        await prisma.systemStat.upsert({
          where: { date: today },
          update: { maxConcurrent: count },
          create: { date: today, maxConcurrent: count }
        });
      }
    } catch (err) {
      console.error('[SystemStats] Update Concurrent Error:', err);
    }
  },

  /**
   * Get Current System Resources (CPU, RAM, Disk)
   */
  async getSystemResources() {
    // 1. CPU Load (Load average or heuristic)
    const cpus = os.cpus().length;
    const loadAvg = os.loadavg();
    const cpuUsage = Math.min(((loadAvg[0] / cpus) * 100).toFixed(2), 100);

    // 2. Memory Usage
    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const memUsage = (((totalMem - freeMem) / totalMem) * 100).toFixed(2);

    // 3. Disk Usage (Async via df)
    let diskUsage = 0;
    try {
      const diskInfo = await new Promise((resolve) => {
        exec("df -h / | tail -1 | awk '{print $5}'", (err, stdout) => {
          if (err) resolve("0%");
          resolve(stdout.trim());
        });
      });
      diskUsage = parseFloat(diskInfo.replace('%', '')) || 0;
    } catch (e) {
      diskUsage = 0;
    }

    return {
      cpuUsage: parseFloat(cpuUsage),
      memUsage: parseFloat(memUsage),
      diskUsage: parseFloat(diskUsage),
      uptime: os.uptime(),
      health: (cpuUsage < 90 && memUsage < 95) ? 'HEALTHY' : 'WARN'
    };
  },

  /**
   * Archive Daily Stats (Membership distribution, etc.)
   */
  async archiveDailyStats() {
    const today = this.getToday();
    try {
      const freeUserCount = await prisma.user.count({ where: { role: { in: ['FREE_USER', 'FREE_TRIAL', 'FREE', 'PENDING'] } } });
      const paidUserCount = await prisma.user.count({ where: { role: { in: ['PAID', 'PRO_USER'] } } });
      
      const resources = await this.getSystemResources();

      await prisma.systemStat.upsert({
        where: { date: today },
        update: {
          freeUserCount,
          paidUserCount,
          cpuUsageAvg: resources.cpuUsage,
          memUsageAvg: resources.memUsage,
          diskUsageAvg: resources.diskUsage,
          healthStatus: resources.health
        },
        create: {
          date: today,
          freeUserCount,
          paidUserCount,
          cpuUsageAvg: resources.cpuUsage,
          memUsageAvg: resources.memUsage,
          diskUsageAvg: resources.diskUsage,
          healthStatus: resources.health
        }
      });
      console.log(`[SystemStats] Daily stats archived for ${today}`);
    } catch (err) {
      console.error('[SystemStats] Archive Error:', err);
    }
  }
};

module.exports = systemStatsService;
