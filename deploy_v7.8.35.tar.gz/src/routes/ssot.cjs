/**
 * [Phase 4-1] SSOT API Router (PostgreSQL/Prisma)
 * Provides Single Source of Truth for Web Dashboard
 */
const express = require('express');
const router = express.Router();
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
const cache = require('../services/cacheService.cjs');
const redis = require('../../platform/infra/redis/client.cjs');

/**
 * GET /api/ssot/top/:n - Top N 종목 11대 지표 조회
 * B-ERR-01 보정: Redis 캐시 레이어 적용
 */
router.get('/top/:n', async (req, res) => {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    const n = Math.min(parseInt(req.params.n) || 5, 20); // 최대 20
    const cacheKey = `mp:top:${n}`;

    try {
        // 1. Redis 캐시 조회 (R-MISS-02 보정)
        const cached = await redis.get(cacheKey);
        if (cached) {
            console.log(`[SSOT-API] Cache Hit: ${cacheKey}`);
            return res.json({ source: 'cache', data: JSON.parse(cached) });
        }

        // 2. Read specific latest recommended codes from latest.json (if available)
        const fs = require('fs');
        const path = require('path');
        let targetCodes = [];
        let reportDataMap = {};
        try {
            const latestPath = path.join(__dirname, '../../data/vip_logs/latest.json');
            if (fs.existsSync(latestPath)) {
                const report = JSON.parse(fs.readFileSync(latestPath, 'utf8'));
                if (report.stocks && report.stocks.length > 0) {
                    targetCodes = report.stocks.slice(0, n).map(s => s.code);
                    report.stocks.slice(0, n).forEach(s => { reportDataMap[s.code] = s; });
                }
            }
        } catch (e) {
            console.error('[SSOT-API] Failed to parse latest.json', e.message);
        }

        // 3. DB 조회 (캐시 미스)
        console.log(`[SSOT-API] Cache Miss: ${cacheKey}. Fetching from PostgreSQL...`);
        let rows = [];
        if (targetCodes.length > 0) {
            for (const code of targetCodes) {
                const snapshot = await prisma.dailyStockSnapshot.findFirst({
                    where: { code: code },
                    orderBy: { createdAt: 'desc' }
                });
                if (snapshot) rows.push(snapshot);
            }
        } else {
            // Fallback: highest scored ever (Legacy behavior)
            rows = await prisma.dailyStockSnapshot.findMany({
                where: { score: { gt: 0 } },
                orderBy: [
                    { score: 'desc' },
                    { createdAt: 'desc' }
                ],
                take: n
            });
        }

        // 3. 필드명 정규화 (Frontend 호환성)
        const normalizedRows = rows.map(r => {
            const merged = reportDataMap[r.code] || {};
            // [v7.7.56] DB SSOT 수치 엄격 매핑 (0값 허용, null/undefined만 JSON 폴백)
            const getVal = (dbVal, jsonVal) => (dbVal !== null && dbVal !== undefined) ? dbVal : (jsonVal || 0);

            return {
                stock_code: r.code,
                stock_name: r.name,
                current_price: getVal(r.currentPrice, merged.current_price),
                change_rate: getVal(r.yield, merged.yield_pct),
                score: getVal(r.score, merged.score),
                trade_amount: r.tradeAmount ? r.tradeAmount.toString() : (merged.trade_amount || '0'),
                trend_type: r.trendType || merged.trend_type || null,
                trend_strength: r.trendStrength || '0', 
                star_grade: r.starGrade || (merged.stars ? String(merged.stars) : '1'), 
                entry_price_1: getVal(r.entryPrice1, merged.entry_price),
                entry_price_2: getVal(r.entryPrice2, merged.entry_price_2),
                stop_loss: getVal(r.stopLoss, merged.stop_loss),
                target_price_1: getVal(r.targetPrice1, merged.target_price_exit),
                target_price_2: getVal(r.targetPrice2, 0),
                updated_at: r.createdAt
            };
        });

        // 4. Write-through 캐시 적재 (30분 TTL)
        await redis.setex(cacheKey, 30 * 60, JSON.stringify(normalizedRows));

        res.json({ source: 'db', data: normalizedRows });
    } catch (err) {
        console.error('[SSOT-API] Error:', err.message);
        res.status(500).json({ error: 'SSOT 데이터 동기화 실패' });
    }
});

module.exports = router;
