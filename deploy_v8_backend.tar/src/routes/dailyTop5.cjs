const express = require('express');
const router = express.Router();
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

// Get Daily Top 5 for a specific date
router.get('/', async (req, res) => {
    try {
        const { date } = req.query;
        if (!date) {
            return res.status(400).json({ error: 'Date parameter is required (YYYY-MM-DD)' });
        }

        const top5 = await prisma.dailyTop5.findMany({
            where: { date: date },
            orderBy: { score: 'desc' },
            take: 5
        });

        res.json(top5);
    } catch (error) {
        console.error('[DailyTop5 API] Error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

module.exports = router;
