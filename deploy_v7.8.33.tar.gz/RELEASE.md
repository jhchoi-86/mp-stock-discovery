# MP Stock Discovery - Release Notes

이 파일은 플랫폼의 코드 수정 및 배포 이력을 관리합니다.

## [v7.8.33] - 2026-04-07
### Added
- **Strategy Engine**: Implemented Automated Trading Strategies (Day Trading & Swing Trading) based on hybrid scores and technical overextension (AMA).

## [v7.8.32] - 2026-04-06
### Fixed
- **Strategy Engine**: Added missing `highest` helper function to support RSI Pivot High calculations.

## [v7.8.31] - 2026-04-06
### Fixed
- **Strategy Engine**: Corrected MTF double-resampling bypass logic (Resample-of-Resample bug).
- **Price Mapping**: Integrated `result_1` (RSI Pivot High/Resistance) to correctly capture breakout entry levels (e.g. 9,440 for 후성).
- **Scoring**: Restored MTF indicator accuracy, significantly improving scores for trending stocks.

## [v7.8.30] - 2026-04-06
### Fixed
- **Strategy Engine**: Resolved double-resampling bug in `calculateSignals` that skewed MTF indicator accuracy.
- **Scoring Service**: Implemented missing KIS Bonus (Institutional/Foreigner Net Buy) logic (up to +10 points).
- **Price Mapping**: Applied sanity guards to Entry 1 to ensure it remains below Current Price (Buy Stop -> Buy Limit logic).
- **Stability**: Fixed Stop Loss mapping to align with the secondary RSI pivot support (result_3).

## [v7.8.29] - 2026-04-06
### 🚩 상태: 구문 오류 수정 및 최종 엔진 배포 (Syntax Fix)
### 🛠 주요 변경 및 조치 사항
1. **분석 엔진 구문 오류 수정**: `analyzer.cjs` 내의 반복문 종료 중괄호(`}`) 누락으로 인한 런타임 에러를 해결했습니다.
2. **데이터 동기화 순서 최적화**: 모든 타임프레임(30M~1D) 분석이 완전히 종료된 후 DB 및 캐시 동기화를 수행하도록 로직을 수정했습니다. 이를 통해 `ScoringService`가 전 시간대 데이터를 참조하여 정확한 하이브리드 점수(0-100)를 산출할 수 있게 되었습니다.

## [v7.8.28] - 2026-04-06
### 🚩 상태: 상용 배포 및 동기화 최적화 진행 중 (Deprecation Warning 대응)
### 🛠 주요 변경 및 조치 사항
1. **배포 프로세스 개선**: Vite 빌드 시의 라이브러리 경고(Deprecated options)를 무시하고 상용 환경 배포를 우선적으로 완료했습니다.

## [v7.8.27] - 2026-04-06
### 🚩 상태: 전략 공식 및 점수 체계 완정 정합 (Formula Alignment)
### 🛠 주요 변경 및 조치 사항
1. **멀티 타임프레임 자동 분석**: 특정 종목 동기화(`--filter`) 시에도 30M~1D 전 시간대를 자동으로 분석하도록 CLI 로직을 고도화하여 100점 만점 기준의 정확한 하이브리드 점수를 복원했습니다.
2. **진입가 매핑 보정**: 1차 진입가는 **2H RSI Pivot (result_2)**, 2차 진입가는 **2H RSI Pivot (result_3)**로 매핑하여 사용자 정의 전략 공식과 플랫폼 데이터를 완벽히 일치시켰습니다.
3. **영속성 안정성 유지**: 진입가 및 목표가 산출 시 기존의 Sanity Guard(현재가 대비 상방/하방 논리)를 유지하면서도 공식의 정확도를 높였습니다.
